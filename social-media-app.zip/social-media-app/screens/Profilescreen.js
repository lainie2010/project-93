import React,{Component} from "react";
import {Text, View} from "react-native";

export default class Profilescreen extends Component{
  render(){
    return(
      <View
      style = {{
        justifyContent:"center",
        alignItems:"center"
      }}>
        <Text>Profile Screen</Text>
      </View>
    )
  }
}